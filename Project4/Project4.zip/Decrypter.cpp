//
//  Decrypter.cpp
//  Project4
//
//  Created by Devyan Biswas on 3/15/18.
//  Copyright © 2018 Devyan Biswas. All rights reserved.
//

#include <stdio.h>
