//
//  History.hpp
//  flatulanSplit
//
//  Created by Devyan Biswas on 1/12/18.
//  Copyright © 2018 Devyan Biswas. All rights reserved.
//

#ifndef HISTORY_INCLUDED
#define HISTORY_INCLUDED

#include "globals.h"

class History
{
public:
    History(int nRows, int nCols);
    bool record(int r, int c);
    void display() const;
private:
    int m_row;
    int m_col;
    int history[MAXROWS][MAXCOLS];
};

#endif /* HISTORY_INCLUDED */
