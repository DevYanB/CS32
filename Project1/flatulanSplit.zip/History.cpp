//
//  History.cpp
//  flatulanSplit
//
//  Created by Devyan Biswas on 1/12/18.
//  Copyright © 2018 Devyan Biswas. All rights reserved.
//

#include "History.h"
#include <iostream>
#include "globals.h"

using namespace std;


History::History(int nRows, int nCols)
: m_row(nRows) , m_col(nCols){
    for(int i = 0; i < m_row; i++){
        for(int j = 0; j < m_col; j++){
            history[i][j] = 0;
        }
    }
}

bool History::record(int r , int c){
    if(r > m_row || c > m_col || r <= 0 || c <= 0){
        return false;
    }
    history[r-1][c-1]++;
    return true;
}

void History::display() const{
    
    char checkGrid[MAXROWS][MAXCOLS];
    int row , col;
    
   /*
    for(row = 0; row < m_row; row++){
        for(col = 0; col < m_col; col++){
            checkGrid[row][col] = '';
            
        }
    }
    */
    int x;
    for(row = 1; row <= m_row; row++){
        for(col = 1; col <= m_col; col++){
            x = history[row-1][col-1];
            if(x == 0){
                checkGrid[row-1][col-1] = '.';
            }
            if(x >= 26){
                checkGrid[row-1][col-1] = 'Z';
            }
            else if(x >= 1 && x <= 25){
                checkGrid[row-1][col-1] = 64 + x;;
            }
        }
    }
    
    clearScreen();
   
    for (row = 0; row < m_row; row++){
        for (col = 0; col < m_col; col++){
            cout << checkGrid[row][col];
        }
        cout << endl;
    }
    cout << endl;
    
}
